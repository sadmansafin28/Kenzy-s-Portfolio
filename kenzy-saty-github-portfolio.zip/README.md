# Kenzy Saty — UGC Creator Portfolio

Personal UGC Creator & Content Creator portfolio.

## Live Website

https://kenzy-saty-portfolio.vercel.app

## GitHub Pages

This repository can also be published using GitHub Pages:
1. Upload `index.html` to the repository.
2. Go to **Settings → Pages**.
3. Select **Deploy from a branch**.
4. Select the `main` branch and `/ (root)`.
5. Save.

The portfolio is a standalone HTML page.
